function sequential(){
// Statements are executed sequentially
alert("This is alert 1");
alert("This is alert 2");
alert("This is alert 3");
alert("This is alert 4");
alert("This is alert 5");
alert("This is alert 6");
}

function conditional(){
	// Conditional Control
	var cash = parseFloat(prompt("How much cash do you have? "));
	if(cash > 5)
	{
		alert("Let’s have subway!");
	}
	else
	{
		alert("Let’s have pizza");
	}
}
function conditional2()
{
	var num = parseFloat(prompt("Enter any num"));
	
	if (num > 0) 
	{ 
	// display an alert message about num when condition is true
	alert("The number is positive");
	} 
	else 
	{ 
	 alert("your number is either 0 or negative");
	// add a statement to display an alert message about num when condition is false

     
	} 
}
function conditional3(){
	// Complete the code 
	// Ask user for the hour of the day, using a 24-hour clock (0--23). Save what user has typed in a variable called hour
	var num = parseFloat(prompt("What time is it using a 24 hour clock?"))
	// Use if-else to check variable hour, and greet user:
	if(num<12){
		alert("good morning!!!");
	}else{
		alert("Good Afternoon!")
	}
	// hour < 12, display “Good Morning!”, otherwise, “Good Afternoon”
     
	} 

