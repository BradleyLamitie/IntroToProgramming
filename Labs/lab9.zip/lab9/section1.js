function computerBMI(){
	var height;
	var weight;
	height = parseFloat(document.getElementById("height").value);
	weight = parseFloat(document.getElementById("weight").value);
	var bmi= weight/(height*height);
	alert("Your BMI is " + bmi);
}