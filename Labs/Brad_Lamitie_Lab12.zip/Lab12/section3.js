var name = "Bowu Zhang";
var courses = [ "Intro to Programming", "Unix", "Software Development", "Operating System"];
alert( "course 0 is "+ courses[0] ); // Should be Intro to Programming
alert( "course 1 is "+ courses[1] ); // Should be Unix
alert( "course 2 is "+ courses[2] ); 
alert( "course 3 is "+ courses[3] );
var index = 0;
alert( "course "+index+" is "+ courses[index] );
alert( "course 3 is "+ courses[3] );
courses[3] = "History of Magic";
alert( "Now, course 3 is "+ courses[3] );
var choice = prompt("Would you like to drop Unix for Software development 2?");
if (choice=="yes"){
	courses[1]="Software development II";
	document.write("course 1 is "+ courses[1]);
}