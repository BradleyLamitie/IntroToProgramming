//Section1 #3

function loop(){
	for (i=0;i<=100;i++){
		document.write("The number is "+ i);
	}
}
//Section1 #4

function loop2(){
	for (i=0;i<=100;i=i+2){
		document.write("The number is "+ i);
	}
}
//Section1 #5

function loop3(){
	for (i=0;i<=100;i=i+5){
		document.write("The number is "+ i);
	}
}

//Section2 #6
function loopexample() {  
 for (var i = 0; i <= 30; i++)
 {
	if( i%2 == 0)
	{
		document.write(i);
	}	
 }
}
//loopexample() rewritten with while loop section2 #7
function loopexample2() {  
 var i= 0;
 while(i<=30){
	 if( i%2 == 0)
	{
		document.write(i);
	}
	i=i+1;
 }
}
//loop() rewritten with while loop section2 #9
function loopwhile() {  
 var i= 0;
 while(i<=100){
	 
	document.write("The number is "+ i);
	
	i=i+1;
 }
}
//loop2() rewritten with while loop section2 #10
function loopwhile2() {  
 var i= 0;
 while(i<=100){
	
	document.write("The number is "+ i);
	
	i=i+2;
 }
}
//loop3() rewritten with while loop section2 #11
function loopwhile3() { 

 var i= 0;
 while(i<=100){
	
		document.write("The number is "+ i);
	
	i=i+5;
 }
 
 
 
 
}
//loopwhile();
//loopwhile2();
//loopwhile3();