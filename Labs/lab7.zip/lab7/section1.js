   function clicksubmit() { 
        // read value from input box with id “hometown”, and save it in a variable called home
	var home = document.getElementById('hometown').value; 
       // display the value of input box using alert
	alert("Oh, you come from "+ home);
    }
function clicksubmit2() { 
	// add code here
	
	// You need one statement to read value from input box you created in step 25, and save it in a variable
	var major = document.getElementById('major').value;
	// You need another statement to display the value of input box using alert
	alert("Oh you're studying "+ major);

    }
