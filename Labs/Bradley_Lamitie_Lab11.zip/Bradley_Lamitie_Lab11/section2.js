 function loopexample() {  
 for (var i = 0; i < 5; i++)
 {
	 document.write("Hello, world!");
 }
}

function loopexample2(){
	for (var i = 0; i<100; i++){
		document.write("I love Marist!");
	}
}
loopexample2();