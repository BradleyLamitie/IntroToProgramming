 var yourname=null;
 var yourschool = null;
 var yourmajor= null;
 
 function clickq1(choice1) {  
// choice1 is a parameter that allows user to pass information to function clickq1
	if(choice1 == "T") {
	// when choice1 == "T", this indicates clickq1(T) is invoked. It further indicates that user clicks true, which means user’s name is Bowu	
		yourname = "Brad";
	}
	else{
	// when choice1 is not "T", this indicates clickq1(F) is invoked. It further indicates that user clicks false, which means user’s name is not Bowu	
		yourname = "not Brad";
	}
}
 function clickq2(choice2) {  
// choice1 is a parameter that allows user to pass information to function clickq1
	if(choice2 == "T") {
	// when choice1 == "T", this indicates clickq1(T) is invoked. It further indicates that user clicks true, which means user’s name is Bowu	
		yourschool = "Marist";
	}
	else{
	// when choice1 is not "T", this indicates clickq1(F) is invoked. It further indicates that user clicks false, which means user’s name is not Bowu	
		yourschool = "not Marist";
	}
}
 function clickq3(choice3) {  
// choice1 is a parameter that allows user to pass information to function clickq1
	if(choice3 == "CS") {
	// when choice1 == "T", this indicates clickq1(T) is invoked. It further indicates that user clicks true, which means user’s name is Bowu	
		yourmajor = "CS";
	}
	else if (choice3=="Math"){
	// when choice1 is not "T", this indicates clickq1(F) is invoked. It further indicates that user clicks false, which means user’s name is not Bowu	
		yourmajor = "Math";
	}else if (choice3=="IT"){
	// when choice1 is not "T", this indicates clickq1(F) is invoked. It further indicates that user clicks false, which means user’s name is not Bowu	
		yourmajor = "IT";
	}else if (choice3=="Other"){
	// when choice1 is not "T", this indicates clickq1(F) is invoked. It further indicates that user clicks false, which means user’s name is not Bowu	
		yourmajor = "Other";
	}
}

function displayresult(){
	var para = document.getElementById("result");
	
	para.innerHTML = "Hi your name is "+ yourname + ", you are studying at " + yourschool + ", and you are majoring in " + yourmajor;
}
