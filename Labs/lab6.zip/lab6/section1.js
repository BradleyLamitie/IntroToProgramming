// Prompt the user for their name
var name = prompt("What is your name?", "Type your name here");
// Show personalized message
alert("Hi, " + name + "! It is very nice to meet you!");
var a = prompt("Enter a decimal number","5.3");
var b = prompt("Enter an integer number","6");
var reala = parseFloat(a);
var realb = parseInt(b);
var result = reala + realb;
alert("The result is " + result);

var x = prompt("Give me a number."); 
var y; 
x = x + 2; 
alert("The value of x is " + x); 
x = x + 1; 
alert("x is now " + x); 
y = x; 
alert("y is " + y);
