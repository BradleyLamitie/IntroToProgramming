function changepicture() {  
	// Find the img element by its id
	var pic = document.getElementById("light");
	if(pic.src.match("redlight")) {
		pic.src = "greenlight.png";
	}
	else{
		pic.src = "redlight.png";
	}
}
