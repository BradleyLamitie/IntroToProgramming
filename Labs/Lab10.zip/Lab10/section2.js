function changepicture2() {  
	// Find the img element by its id
	var pic = document.getElementById("light");
	var paragraph = document.getElementById("picturename");
	if(pic.src.match("redlight")) {
		pic.src = "greenlight.png";
		paragraph.innerHTML=("Green Light");
	}
	else if(pic.src.match("greenlight"))
	{
		pic.src = "yellowlight.png";
		paragraph.innerHTML=("Yellow Light");
	}
	else{
		pic.src = "redlight.png";
		paragraph.innerHTML=("Red Light");
	}
}
