
function changescene() {  
	// Find the img element by its id
	var para1 = document.getElementById("scenetitle");
	var para2 = document.getElementById("storycontents");
	if(para1.innerHTML == "Scene 1") {
		para1.innerHTML = "Scene 2";
		para2.innerHTML = "Snow White father, the King, takes a new and second wife, who is very beautiful, but a wicked and vain woman. The new queen, possesses a magic mirror, which she asks every morning, 'Magic mirror on the wall, who is the fairest one of all? ' The mirror always replies: 'My Queen, you are the fairest one of all. ' But as Snow White grows up, and when the Queen asks her mirror, it tells her that Snow White is the fairest. ";
	}else if(para1.innerHTML== "Scene 2"){
		para1.innerHTML = "Scene 3";
		para2.innerHTML = "This gives the queen a great shock. She hates Snow White more and more each day. Eventually, the Queen orders a huntsman to take Snow White into the deepest woods to be killed. The huntsman takes Snow White into the forest. The huntsman leaves her behind alive, convinced that the girl would be eaten by some wild animal  ";
	}else if(para1.innerHTML== "Scene 3"){
		para1.innerHTML = "Scene 4";
		para2.innerHTML = "After wandering through the forest for days, Snow White discovers a tiny cottage belonging to a group of Seven Dwarfs. When the seven dwarfs return home, they immediately become aware that someone sneaked in secretly, because everything in their home is in disorder. During their loud discussion about who sneaked in, they discover the sleeping Snow White. ";
	}else if(para1.innerHTML== "Scene 4"){
		para1.innerHTML = "Scene 5";
		para2.innerHTML = "The Queen is horrified to learn that the huntsman has betrayed her and that Snow White is still alive. The Queen then walks to the cottage of the dwarfs and offers her colorful, silky laced bodices and convinces the girl to take the most beautiful bodice as a present. Then the Queen laces it so tightly that Snow White faints, causing the Queen to leave her for dead. But the dwarfs return just in time, and Snow White revives when the dwarfs loosen the laces. The next morning the Queen consults her mirror anew and the mirror reveals Snow White's survival. Now infuriated, the Queen dresses as a comb seller and convinces Snow White to take a beautiful comb as a present. She brushes Snow White's hair with a poisoned comb, and the girl faints again, but she is again revived by the dwarfs. ";
	}else if(para1.innerHTML== "Scene 5"){
		para1.innerHTML = "Scene 6";
		para2.innerHTML = "As a third and last attempt to rid herself of Snow White, she secretly consults the darkest magic and makes a poisoned apple, and in the disguise of a farmer's wife, she offers it to Snow White. This time the dwarfs are unable to revive the girl because they cannot find the source of Snow White's poor health, and assuming that she is dead, they place her in a glass coffin. Time passes and a prince traveling through the land sees Snow White. He strides to her coffin and, enchanted by her beauty, instantly falls in love with her. The dwarfs succumb to his entreaties to let him have the coffin, and as his servants carry the coffin away, they stumble on some roots. The tremor caused by the stumbling causes the piece of poisoned apple to dislodge from Snow White's throat, awakening her. The Prince then declares his love for her, and soon a wedding is planned. The couple invite every queen and king to come to the wedding party, including Snow White's step-mother. Not knowing that this new queen was indeed her stepdaughter, she arrives at the wedding, and her heart fills with the deepest of dread when she realizes the truth. ";
	}
	
}
