   function clicksubmit2() { 
	// add code here
	// You need statements to read value from input boxes (Customer name, telephone, email address, delivery time, delivery instructions), and save them each in a variable
	var name = document.getElementById("name").value;
	var phone = document.getElementById("phone").value;
	var email = document.getElementById("email").value;
	var time = document.getElementById("time").value;
	var  instructions= document.getElementById("instructions").value;


	// You don’t need to read values of Pizza size and Pizza toppings -- We will work on them in the future labs

	// You need statements to display the value of input boxes using alert
	alert(name + "can be contacted at " + phone + " or emailed at " + email+ ".");
	alert("They would like it delivered at " + time + " with these instructions: " + instructions + ".");
    }
