   function clicksubmit() { 
	// read value from input boxes by their id, and save them in variables
	var firstname = document.getElementById('fname').value; 
	var lastname = document.getElementById('lname').value; 
	var major = document.getElementById('major').value; 
	var email = document.getElementById('email').value; 
	var cell = document.getElementById('phone').value; 
	var score = document.getElementById('rating').value; 
// reading values from a drop-down list or from radio type input boxes is very complicated.
// we will discuss how to read values from drop-down lists and radio type input boxes later, after we learn if-else and for loops		
       // display the value of input box using alert
alert(firstname + " "+ lastname + " is majoring in " + major + ". "+ firstname + " can be reached at "+cell + ". "+ firstname + "'s rating of our website is "+ score);
alert("Hi, " + firstname + "! Thanks for your participation in the survey! "+ " A copy of this survey has been sent to  your email address at " + email );
   }